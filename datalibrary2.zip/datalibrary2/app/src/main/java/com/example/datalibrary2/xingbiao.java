package com.example.datalibrary2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class xingbiao extends AppCompatActivity {
    private DatabaseHelper db;
    private ArrayAdapter<String> adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_xingbiao);

        ListView list5=findViewById(R.id.list5);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        //datas.add("全部单词如下：");


        db = new DatabaseHelper(xingbiao.this,"danciben", null, 1);




        List<String> datas=new ArrayList<>();
        adapter = new ArrayAdapter<>(xingbiao.this,android.R.layout.simple_list_item_1,datas);
        list5.setAdapter(adapter);

        Cursor cursor=db.getReadableDatabase().query("danciben",null,"xingbiao=?", new String[]{"1"},null,null,null);
        String danci1=" ";
        String danci2=" ";
        while(cursor.moveToNext()){
            //String id=cursor.getString(cursor.getColumnIndex("id"));
            String danci=cursor.getString(cursor.getColumnIndex("danci"));
            String zhushi=cursor.getString(cursor.getColumnIndex("zhushi"));
            danci1=danci1+danci+"："+zhushi+"\n";
            danci2=danci;
            datas.add(danci2);
        }//text3.setText(danci1);
        list5.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String abc= (String) list5.getItemAtPosition(position);
                // Toast.makeText(chaozhaoquanbu.this,abc,Toast.LENGTH_SHORT).show();
                Intent intent1=new Intent(xingbiao.this,xiangqing.class);
                intent1.putExtra("danci",abc);
                startActivity(intent1);
            }
        });
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        ListView list5=findViewById(R.id.list5);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        //datas.add("全部单词如下：");


        db = new DatabaseHelper(xingbiao.this,"danciben", null, 1);




        List<String> datas=new ArrayList<>();
        adapter = new ArrayAdapter<>(xingbiao.this,android.R.layout.simple_list_item_1,datas);
        list5.setAdapter(adapter);

        Cursor cursor=db.getReadableDatabase().query("danciben",null,"xingbiao=?", new String[]{"1"},null,null,null);
        String danci1=" ";
        String danci2=" ";
        while(cursor.moveToNext()){
            //String id=cursor.getString(cursor.getColumnIndex("id"));
            String danci=cursor.getString(cursor.getColumnIndex("danci"));
            String zhushi=cursor.getString(cursor.getColumnIndex("zhushi"));
            danci1=danci1+danci+"："+zhushi+"\n";
            danci2=danci;
            datas.add(danci2);
        }//text3.setText(danci1);
        list5.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String abc= (String) list5.getItemAtPosition(position);
                // Toast.makeText(chaozhaoquanbu.this,abc,Toast.LENGTH_SHORT).show();
                Intent intent1=new Intent(xingbiao.this,xiangqing.class);
                intent1.putExtra("danci",abc);
                startActivity(intent1);
            }
        });
    }
}