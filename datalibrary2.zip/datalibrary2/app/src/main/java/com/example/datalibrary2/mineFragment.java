package com.example.datalibrary2;

import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;


public class mineFragment extends Fragment {


    List<String> datas=new ArrayList<>();
    private ArrayAdapter<String> adapter;
    public mineFragment() {
        // Required empty public constructor
    }





    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        return inflater.inflate(R.layout.fragment_mine, null, false);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        ListView list=getActivity().findViewById(R.id.list);

        datas.add("持续更新中：");
        adapter = new ArrayAdapter<String>(getContext(),android.R.layout.simple_list_item_1,datas);
        list.setAdapter(adapter);

      //  datas.add("11月18日 添加日志功能");
       // datas.add("11月18日 开始更新日志");
       // datas.add("11月19日 listview滑动查看");
       // datas.add("11月20日 在线翻译");
       // datas.add("11月21日 listview点击事件");
       // datas.add("11月22日 menu菜单");
    }
}