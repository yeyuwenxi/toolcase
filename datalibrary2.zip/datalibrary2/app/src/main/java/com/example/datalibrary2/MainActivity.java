package com.example.datalibrary2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
       // getSupportActionBar().setDisplayShowTitleEnabled(false);//隐藏显示标题


        LinearLayout button1=findViewById(R.id.shouye);
        LinearLayout button2=findViewById(R.id.fanyi);
        LinearLayout button3=findViewById(R.id.wode);
        TextView text1=findViewById(R.id.text1);
        TextView text2=findViewById(R.id.text2);
        TextView text3=findViewById(R.id.text3);
//设置初始页面
        FragmentManager fm=getSupportFragmentManager();
        FragmentTransaction ft=fm.beginTransaction();
        Fragment f=new mainFragment();
        ft.replace(R.id.fragment1,f);
        ft.commit();
//页面切换
 Log.i("1234","1234");
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentManager fm=getSupportFragmentManager();
                FragmentTransaction ft=fm.beginTransaction();
                Fragment f=new mainFragment();
           ft.replace(R.id.fragment1,f);
           ft.commit();
           text1.setTextColor(Color.BLUE);
           text2.setTextColor(Color.GRAY);
                text3.setTextColor(Color.GRAY);
            }
        });
        //页面切换
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentManager fm=getSupportFragmentManager();
                FragmentTransaction ft=fm.beginTransaction();
                Fragment f= new translateFragment();
                ft.replace(R.id.fragment1,f);
                ft.commit();
                text2.setTextColor(Color.BLUE);
                text1.setTextColor(Color.GRAY);
                text3.setTextColor(Color.GRAY);
            }
        });
        //页面切换
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentManager fm=getSupportFragmentManager();
                FragmentTransaction ft=fm.beginTransaction();
                Fragment f=new mineFragment();
                ft.replace(R.id.fragment1,f);
                ft.commit();
                text3.setTextColor(Color.BLUE);
                text2.setTextColor(Color.GRAY);
                text1.setTextColor(Color.GRAY);
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater=getMenuInflater();
inflater.inflate(R.menu.menu,menu);//解析菜单资源文件


        return super.onCreateOptionsMenu(menu);


    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.chazhao:{

                Intent intent1=new Intent();
                intent1.setClass(MainActivity.this,chazhao.class);
                startActivity(intent1);
           break; }
            case R.id.tianjia:{Intent intent2=new Intent();
                intent2.setClass(MainActivity.this,tianjia.class);
                startActivity(intent2);
            break;}
            case R.id.shanchu:{Intent intent3=new Intent();
                intent3.setClass(MainActivity.this,shanchu.class);
                startActivity(intent3);
            break;}}

        return super.onOptionsItemSelected(item);
    }
}