package com.example.datalibrary2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class shanchu extends AppCompatActivity {
    private DatabaseHelper db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shanchu);

        Button button14=(Button)findViewById(R.id.button14);//删除
        EditText shanchu=findViewById(R.id.shanchu);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        db = new DatabaseHelper(shanchu.this,"danciben", null, 1);

        button14.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String key=shanchu.getText().toString();
                if(key.length()==0)
                { Toast.makeText(shanchu.this,"请输入要删除的单词",Toast.LENGTH_SHORT).show();

                }else{
                    db.getWritableDatabase().delete("danciben","danci=?",new String[]{key});
                    Toast.makeText(shanchu.this,"删除成功",Toast.LENGTH_SHORT).show();}
            }
        });
    }
}