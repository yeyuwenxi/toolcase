package com.example.datalibrary2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class xiangqing extends AppCompatActivity {
    private DatabaseHelper db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_xiangqing);
        TextView danci1=findViewById(R.id.danci1);

        Button shanchu=findViewById(R.id.shanchudanci);
        Button yibeihui=findViewById(R.id.yibeihui);
        Button weibeihui=findViewById(R.id.weibeihui);
        Button xingbiao=findViewById(R.id.xingbiao);
        Button quxiao=findViewById(R.id.quxiao);
        Intent intent1=getIntent() ;
        String danci=intent1.getStringExtra("danci");
       // Toast.makeText(xiangqing.this,danci,Toast.LENGTH_SHORT).show();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        db = new DatabaseHelper(xiangqing.this,"danciben", null, 1);

        Cursor cursor=db.getReadableDatabase().query("danciben",null,"danci=?", new String[]{danci},null,null,null);
        String danci2=" ";
        while(cursor.moveToNext()){
            String danci3=cursor.getString(cursor.getColumnIndex("danci"));
            String zhushi=cursor.getString(cursor.getColumnIndex("zhushi"));
            String xiangqing1=cursor.getString(cursor.getColumnIndex("xiangqing"));
            danci2="单词："+danci3+"\n"+"注释："+zhushi+"\n"+"详情："+xiangqing1+"\n";

        } danci1.setText(danci2);

shanchu.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {

        db.getWritableDatabase().delete("danciben","danci=?", new String[]{danci});
finish();
    }
});
yibeihui.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        ContentValues values=new ContentValues();
        values.put("beihui",1);
        db.getWritableDatabase().update("danciben",values,"danci=?", new String[]{danci});
    }
});
        weibeihui.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ContentValues values=new ContentValues();
                values.put("beihui",0);
                db.getWritableDatabase().update("danciben",values,"danci=?", new String[]{danci});
            }
        });
        xingbiao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ContentValues values=new ContentValues();
                values.put("xingbiao",1);
                db.getWritableDatabase().update("danciben",values,"danci=?", new String[]{danci});
            }
        });
        quxiao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ContentValues values=new ContentValues();
                values.put("xingbiao",0);
                db.getWritableDatabase().update("danciben",values,"danci=?", new String[]{danci});
            }
        });
    }

}