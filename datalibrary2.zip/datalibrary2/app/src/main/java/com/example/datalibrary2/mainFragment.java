package com.example.datalibrary2;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;


public class mainFragment extends Fragment {



    public mainFragment() {
        // Required empty public constructor
    }




    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v=inflater.inflate(R.layout.fragment_main, null, false);


        return v ;
    }
    private ArrayAdapter<String> adapter;
    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);



        ListView list2=getActivity().findViewById(R.id.list2);
        List<String> datas=new ArrayList<>();
        adapter = new ArrayAdapter<>(getContext(),android.R.layout.simple_list_item_1,datas);
        list2.setAdapter(adapter);
        datas.add("全部单词");
        datas.add("已背会单词");
        datas.add("未背会单词");
        datas.add("星标单词");
        list2.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {


                switch (position){
                    case 0:{
                        Intent intent5=new Intent();
                        intent5.setClass(getActivity(),chaozhaoquanbu.class);
                        startActivity(intent5);
                        break;
                    }
                    case 1:{
                        Intent intent5=new Intent();
                        intent5.setClass(getActivity(),yibeihui.class);
                        startActivity(intent5);
                        break;
                    }
                    case 2:{
                        Intent intent5=new Intent();
                        intent5.setClass(getActivity(),weibeihui.class);
                        startActivity(intent5);
                        break;
                    }
                    case 3:{
                        Intent intent5=new Intent();
                        intent5.setClass(getActivity(),xingbiao.class);
                        startActivity(intent5);
                        break;
                    }

                }
            }
        });



    }

}