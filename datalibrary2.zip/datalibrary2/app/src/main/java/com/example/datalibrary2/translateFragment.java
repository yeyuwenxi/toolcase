package com.example.datalibrary2;

import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.Toast;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link translateFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class translateFragment extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;








    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v=inflater.inflate(R.layout.fragment_translate, container, false);


        return v;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        //WebView web=(WebView) getActivity().findViewById(R.id.web);
        // web.getSettings().setJavaScriptEnabled(true);
        // web.setWebViewClient(new WebViewClient());
        // web.loadUrl("http://www.baidu.com");
        Button button4=getActivity().findViewById(R.id.button4);
        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.i("123","123");
                WebView web=(WebView) getActivity().findViewById(R.id.web);
                web.getSettings().setJavaScriptEnabled(true);
                web.setWebViewClient(new WebViewClient());
                web.loadUrl("https://fanyi.baidu.com/?aldtype=16047#auto/zh");
                Toast.makeText(getActivity(),"疯狂加载中，请稍后",Toast.LENGTH_SHORT).show();

            }
        });
        Button button17=getActivity().findViewById(R.id.button17);
        button17.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.i("123","123");
                WebView web=(WebView) getActivity().findViewById(R.id.web);
                web.getSettings().setJavaScriptEnabled(true);
                web.setWebViewClient(new WebViewClient());
                web.loadUrl("http://fanyi.youdao.com/");
                Toast.makeText(getActivity(),"疯狂加载中，请稍后",Toast.LENGTH_SHORT).show();

            }
        });
    }
}