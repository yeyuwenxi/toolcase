package com.example.datalibrary2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class tianjia extends AppCompatActivity {
    private DatabaseHelper db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tianjia);
        Button button15=(Button) findViewById(R.id.button15);//添加

        EditText danci=(EditText)findViewById(R.id.danci);
        EditText shiyi=(EditText)findViewById(R.id.shiyi);
        EditText xiangqing1=(EditText)findViewById(R.id.xiangqing);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        db = new DatabaseHelper(tianjia.this,"danciben", null, 1);
        //数据库实际上是没有被创建或者打开的，直到getWritableDatabase() 或者 getReadableDatabase() 方法中的一个被调用时才会进行创建或者打开
        db.getWritableDatabase();

        button15.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String ciyu=danci.getText().toString();
                String zhushi=shiyi.getText().toString();
                String xiangqing=xiangqing1.getText().toString();
                if(ciyu.length()==0||zhushi.length()==0)
                {   Toast.makeText(tianjia.this,"请将单词和注释填写完整",Toast.LENGTH_SHORT).show();
                } else{
                    Cursor cursor = db.getReadableDatabase().query("danciben", null, "danci=?", new String[]{ciyu}, null, null, null);
                    if (cursor.getCount() == 0){
                        //Log.d(TAG, "加入"+provinceName+"到数据库中");
                        //插入数据

                        insertData(db.getReadableDatabase(),ciyu,zhushi,xiangqing);
                        Toast.makeText(tianjia.this,"添加成功",Toast.LENGTH_SHORT).show();
                    }else {
                        //Log.d(TAG, "数据库中已存在" + provinceName);
                        Toast.makeText(tianjia.this,"单词已存在，插入失败！\n请删除后重新插入",Toast.LENGTH_SHORT).show();
                    }}


            }
        });
    }
    private void insertData(SQLiteDatabase sqLiteDatabase, String ci, String zhushi,String xiangqing2){
        ContentValues values=new ContentValues();
        values.put("danci",ci);
        values.put("zhushi",zhushi);
        values.put("xiangqing",xiangqing2);
        values.put("beihui",0);
        values.put("xingbiao",0);
        sqLiteDatabase.insert("danciben",null,values);
    }
}