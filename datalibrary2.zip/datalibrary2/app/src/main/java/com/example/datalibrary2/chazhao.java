package com.example.datalibrary2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class chazhao extends AppCompatActivity {
    private ArrayAdapter<String> adapter;
    private DatabaseHelper db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chazhao);

        Button button11=(Button)findViewById(R.id.button11);//查找
        EditText chazhao=(EditText) findViewById(R.id.chazhao);
        ListView xianshi= findViewById(R.id.xianshi);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        db = new DatabaseHelper(chazhao.this,"danciben", null, 1);


        button11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //xianshi.setText(" ");
                List<String> datas=new ArrayList<>();
                adapter = new ArrayAdapter<>(chazhao.this,android.R.layout.simple_list_item_1,datas);
                xianshi.setAdapter(adapter);

                String key=chazhao.getText().toString();
                Cursor cursor=db.getReadableDatabase().query("danciben",null,"danci like?", new String[]{key+"%"},null,null,null);
                String danci1=" ";
                while(cursor.moveToNext()){
                    String danci=cursor.getString(cursor.getColumnIndex("danci"));
                    String zhushi=cursor.getString(cursor.getColumnIndex("zhushi"));
                    danci1=danci1+danci+"："+zhushi+"\n";
            datas.add(danci);
                } //xianshi.setText(danci1);
            }
        });
        xianshi.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String abc= (String) xianshi.getItemAtPosition(position);
               // Log.d("abc", String.valueOf(id));
                Intent intent1=new Intent(chazhao.this,xiangqing.class);
                intent1.putExtra("danci",abc);
                startActivity(intent1);
            }
        });
    }
}